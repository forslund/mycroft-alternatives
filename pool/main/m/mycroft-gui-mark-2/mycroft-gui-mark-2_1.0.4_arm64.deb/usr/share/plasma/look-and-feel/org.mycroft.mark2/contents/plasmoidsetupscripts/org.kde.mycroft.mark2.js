applet.wallpaperPlugin = 'org.kde.color'
applet.writeConfig("rotation", "CW")
applet.currentConfigGroup = ["Wallpaper", "org.kde.color", "General"]
applet.writeConfig("Color", "0,0,0")
applet.reloadConfig()

